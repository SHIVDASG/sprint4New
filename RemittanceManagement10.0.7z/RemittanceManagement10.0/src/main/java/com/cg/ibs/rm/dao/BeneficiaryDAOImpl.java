package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.apache.log4j.Logger;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CustomerBean;
import com.cg.ibs.rm.exception.ExceptionMessages;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.ui.Status;
import com.cg.ibs.rm.util.JpaUtil;

public class BeneficiaryDAOImpl implements BeneficiaryDAO {
	private static Logger logger = Logger.getLogger(BeneficiaryDAOImpl.class);
	EntityManager manager = JpaUtil.getEntityManger();

	@Override
	public Set<Beneficiary> getDetails(BigInteger uci) {// returns set of beneficiaries for a given
		// uci
		logger.info("entering into getDetails method of BeneficiaryDAOImpl class");
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Beneficiary> query = builder.createQuery(Beneficiary.class);
		Root<CustomerBean> custRoot = query.from(CustomerBean.class);
		Join<CustomerBean, Beneficiary> beneficiaries = custRoot.join("beneficiaries");
		query.select(beneficiaries).where(builder.and(builder.equal(custRoot.get("uci"), uci),
				builder.equal(beneficiaries.get("status"), Status.ACTIVE)));
		return new HashSet<Beneficiary>(manager.createQuery(query).getResultList());
	}

	@Override
	public boolean copyDetails(BigInteger uci, Beneficiary beneficiary) throws IBSExceptions {// copying values into the
		// final beneficiary
		// database
		boolean result = false;
		logger.info("entering into copyDetails method of BeneficiaryDAOImpl class");
		if (manager.find(Beneficiary.class, beneficiary.getAccountNumber()) == null
				|| beneficiary.getStatus().equals(Status.BLOCKED)) {
			CustomerBean customer = manager.find(CustomerBean.class, uci);
			beneficiary.setCustomer(customer);
			manager.persist(beneficiary);
			result = true; // must include WHERE
		} else {
			throw new IBSExceptions(ExceptionMessages.ERROR3);
		}
		return result;
	}

	@Override
	public Beneficiary getBeneficiary(BigInteger accountNumber) throws IBSExceptions {// returns beneficiary
		// object
		logger.info("entering into getBeneficiary method of BeneficiaryDAOImpl class");
		Beneficiary beneficiary = manager.find(Beneficiary.class, accountNumber);
		if (beneficiary != null) {
			return beneficiary;
		} else {
			throw new IBSExceptions(ExceptionMessages.BENEFICIARY_DOESNT_EXIST);
		}
	}

	@Override
	public boolean updateDetails(Beneficiary beneficiary1) throws IBSExceptions {
		logger.info("entering into updateDetails method of BeneficiaryDAOImpl class");
		boolean check = false;
		Beneficiary beneficiary = manager.find(Beneficiary.class, beneficiary1.getAccountNumber());
		if (null != beneficiary && beneficiary.getStatus().equals(Status.ACTIVE)) {
			beneficiary.setStatus(Status.PENDING);
			manager.merge(beneficiary);
			check = true;
		} else {
			throw new IBSExceptions(ExceptionMessages.BENEFICIARY_DOESNT_EXIST);
		}
		return check;

	}

	
	@Override
	public boolean deleteDetails(BigInteger accountNumber) throws IBSExceptions {
		logger.info("entering into deleteDetails method of BeneficiaryDAOImpl class");
		boolean check = false;
		Beneficiary beneficiary = manager.find(Beneficiary.class, accountNumber);
		if (null != beneficiary && beneficiary.getStatus().equals(Status.ACTIVE)) {
			manager.remove(beneficiary);
			check = true;
		} else {
			throw new IBSExceptions(ExceptionMessages.BENEFICIARY_DOESNT_EXIST);
		}
		return check;

	}

}