package com.cg.ibs.rm.service;

import java.math.BigInteger;

import com.cg.ibs.rm.dao.CustomerDAOImpl;

public class CustomerServiceImpl implements CustomerService {
	CustomerDAOImpl customerDAO = new CustomerDAOImpl();

	public String returnName(BigInteger uci) {
		return customerDAO.returnName(uci);
	}

	public boolean checkUciList(BigInteger uci) {// check whether uci is present or not
		boolean checkUci = false;
		if (customerDAO.getUciList().contains(uci)) {
			checkUci = true;
		}
		return checkUci;
	}
}
