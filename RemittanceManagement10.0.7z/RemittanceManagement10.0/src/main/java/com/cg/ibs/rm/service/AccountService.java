package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.rm.bean.AccountBean;

public interface AccountService {
	
	public Set<AccountBean> getAccountsOfUci(BigInteger uci);
}
