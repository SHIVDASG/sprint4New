package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.rm.bean.AccountBean;

public interface AccountDao {
	public Set<AccountBean> getAccounts(BigInteger uci);
}
